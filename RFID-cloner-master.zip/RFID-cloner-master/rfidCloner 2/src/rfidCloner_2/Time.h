#ifndef TIME_H
#define TIME_H

#include <Arduino.h>

String GetTimeSince(long milliseconds);









#endif
